# BookBridge

Run locally:
    npm install
    npm start        # http://localhost:3000

Deploy on Render: New > Web Service, Build: `npm install`, Start: `npm start`.
Env vars: JWT_SECRET=<any long random text>, DATA_DIR=/var/data (attach a Persistent Disk mounted at /var/data).
