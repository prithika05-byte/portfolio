var S = { token: localStorage.getItem('bb_token'), user: JSON.parse(localStorage.getItem('bb_user') || 'null') };
var view = document.getElementById('view');

function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function toast(m){var t=document.getElementById('toast');t.textContent=m;t.style.display='block';setTimeout(function(){t.style.display='none'},2800)}

async function api(url, opts) {
  opts = opts || {};
  opts.headers = opts.headers || {};
  if (S.token) opts.headers.Authorization = 'Bearer ' + S.token;
  if (opts.body && !(opts.body instanceof FormData)) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  var r = await fetch(url, opts);
  var d = await r.json().catch(function(){return {}});
  if (!r.ok) throw new Error(d.error || 'Something went wrong');
  return d;
}

function nav() {
  var h = '<a href="#home">Home</a><a href="#about">About</a><a href="#how">How it Works</a><a href="#contact">Contact</a>';
  if (S.user) {
    h += S.user.role === 'donor' ? '<a href="#donate">Donate</a><a href="#dash">Requests</a>' : '<a href="#find">Find a Book</a><a href="#dash">My Requests</a>';
    h += '<a onclick="logout()">Logout (' + esc(S.user.name) + ')</a>';
  } else h += '<a href="#login">♙ Login</a>';
  document.getElementById('links').innerHTML = h;
}
function logout(){S.token=null;S.user=null;localStorage.clear();location.hash='#home';route()}

var pages = {
  home: function () {
    view.innerHTML = '<div class="hero"><div style="font-size:60px">📚</div><p>Welcome to</p><h1>BookBridge</h1><h3>Book Donation &amp; Sharing Platform</h3>' +
      '<p>Connecting unused books with students who need them.</p>' +
      '<div class="btns"><a class="btn" href="#donate">🎁 Donate a Book</a><a class="btn alt" href="#find">⌕ Find a Book</a></div></div>' +
      '<div class="grid"><div class="card"><h3>📖 Give Books</h3>Share knowledge</div><div class="card"><h3>👥 Help Students</h3>Empower learning</div>' +
      '<div class="card"><h3>🍃 Save Environment</h3>Reuse &amp; recycle</div><div class="card"><h3>♡ Build Community</h3>Stronger together</div></div>';
  },
  about: function () { view.innerHTML = '<div class="card"><h2>About</h2>BookBridge connects donors with students who need books.</div>'; },
  how: function () { view.innerHTML = '<div class="card"><h2>How it Works</h2><ol><li>Donor uploads a book.</li><li>Student requests it.</li><li>Donor accepts the request.</li><li>Status becomes <b>Completed Successfully</b> and the student downloads the book.</li></ol></div>'; },
  contact: function () { view.innerHTML = '<div class="card"><h2>Contact</h2>Email: support@bookbridge.example</div>'; },

  login: function () {
    view.innerHTML = '<div class="card"><h2>Login</h2><input id="le" placeholder="Email"><input id="lp" type="password" placeholder="Password"><button class="btn" id="lb">Login</button></div>' +
      '<div class="card"><h2>Register</h2><input id="rn" placeholder="Name"><input id="re" placeholder="Email"><input id="rp" type="password" placeholder="Password">' +
      '<select id="rr"><option value="student">Student</option><option value="donor">Donor</option></select><button class="btn" id="rb">Register</button></div>';
    document.getElementById('lb').onclick = function () {
      done(api('/api/login', { method: 'POST', body: { email: v('le'), password: v('lp') } }));
    };
    document.getElementById('rb').onclick = function () {
      done(api('/api/register', { method: 'POST', body: { name: v('rn'), email: v('re'), password: v('rp'), role: v('rr') } }));
    };
    function v(i){return document.getElementById(i).value.trim()}
    function done(p){p.then(function(d){
      S.token=d.token;S.user=d.user;localStorage.setItem('bb_token',d.token);localStorage.setItem('bb_user',JSON.stringify(d.user));
      location.hash = d.user.role==='donor'?'#donate':'#find'; route();
    }).catch(function(e){toast(e.message)})}
  },

  donate: function () {
    if (!need('donor')) return;
    view.innerHTML = '<div class="card"><h2>🎁 Donate a Book</h2><input id="bt" placeholder="Book title"><input id="ba" placeholder="Author">' +
      '<textarea id="bd" rows="3" placeholder="Description"></textarea><input id="bf" type="file" accept=".pdf,.epub,.txt"><button class="btn" id="bb">Donate</button></div>';
    document.getElementById('bb').onclick = function () {
      var f = new FormData();
      f.append('title', document.getElementById('bt').value);
      f.append('author', document.getElementById('ba').value);
      f.append('description', document.getElementById('bd').value);
      f.append('file', document.getElementById('bf').files[0] || '');
      api('/api/books', { method: 'POST', body: f }).then(function(){toast('Book donated ✅');location.hash='#dash'})
        .catch(function(e){toast(e.message)});
    };
  },

  find: async function () {
    view.innerHTML = '<div class="card"><h2>⌕ Find a Book</h2><input id="q" placeholder="Search title or author"></div><div id="list"></div>';
    async function load() {
      var books = await api('/api/books?q=' + encodeURIComponent(document.getElementById('q').value));
      document.getElementById('list').innerHTML = books.length ? books.map(function (b) {
        return '<div class="card"><b>' + esc(b.title) + '</b><div class="mut">' + esc(b.author) + ' · donated by ' + esc(b.donor) + '</div><p>' + esc(b.description) +
          '</p><button class="btn" onclick="requestBook(\'' + b.id + '\')">Request Book</button></div>';
      }).join('') : '<p class="mut">No books found.</p>';
    }
    document.getElementById('q').oninput = load; load();
  },

  dash: async function () {
    if (!S.user) { location.hash = '#login'; return; }
    var donor = S.user.role === 'donor';
    var list = await api(donor ? '/api/requests/incoming' : '/api/requests/mine');
    var h = '<h2>' + (donor ? 'Student Requests' : 'My Requests') + '</h2>';
    if (!list.length) h += '<p class="mut">No requests yet.</p>';
    list.forEach(function (r) {
      h += '<div class="card"><b>' + esc(r.title) + '</b>' + (donor ? '<div class="mut">Requested by ' + esc(r.student) + '</div>' : '') + '<p>';
      if (r.status === 'completed') h += '<span class="tag completed">✅ Completed Successfully</span>';
      else if (r.status === 'rejected') h += '<span class="tag rejected">Rejected</span>';
      else h += '<span class="tag pending">⏳ Pending</span>';
      h += '</p>';
      if (donor && r.status === 'pending') h += '<button class="btn" onclick="act(\'' + r.id + '\',\'accept\')">Accept</button> <button class="btn alt" onclick="act(\'' + r.id + '\',\'reject\')">Reject</button>';
      if (!donor && r.status === 'completed') h += '<button class="btn" onclick="download(\'' + r.id + '\')">⬇ Download Book</button>';
      h += '</div>';
    });
    view.innerHTML = h;
  }
};

function need(role) {
  if (!S.user) { location.hash = '#login'; return false; }
  if (S.user.role !== role) { toast('Only ' + role + 's can open this page'); location.hash = '#home'; return false; }
  return true;
}
function requestBook(id) {
  if (!S.user) { location.hash = '#login'; return; }
  api('/api/requests', { method: 'POST', body: { bookId: id } }).then(function () { toast('Request sent ✅'); }).catch(function (e) { toast(e.message); });
}
function act(id, what) {
  api('/api/requests/' + id + '/' + what, { method: 'POST' }).then(function () { toast(what === 'accept' ? 'Completed Successfully ✅' : 'Rejected'); route(); }).catch(function (e) { toast(e.message); });
}
async function download(id) {
  try {
    var r = await fetch('/api/requests/' + id + '/download', { headers: { Authorization: 'Bearer ' + S.token } });
    if (!r.ok) throw new Error((await r.json()).error);
    var cd = r.headers.get('Content-Disposition') || '';
    var m = /filename="?([^";]+)"?/.exec(cd);
    var blob = await r.blob(), a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = m ? decodeURIComponent(m[1]) : 'book';
    document.body.appendChild(a); a.click(); a.remove();
  } catch (e) { toast(e.message); }
}
function route() {
  nav();
  var p = (location.hash || '#home').slice(1);
  (pages[p] || pages.home)();
}
window.onhashchange = route; route();
