const express = require('express');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'change-this-secret';
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOADS = path.join(DATA, 'uploads');
const DB = path.join(DATA, 'db.json');
fs.mkdirSync(UPLOADS, { recursive: true });

function read() {
  try { return JSON.parse(fs.readFileSync(DB, 'utf8')); }
  catch (e) { return { users: [], books: [], requests: [] }; }
}
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2)); }
function id() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOADS,
    filename: (req, file, cb) => cb(null, id() + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: 25 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = ['.pdf', '.epub', '.txt'].includes(path.extname(file.originalname).toLowerCase());
    cb(ok ? null : new Error('Only PDF, EPUB or TXT files allowed'), ok);
  }
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function auth(role) {
  return (req, res, next) => {
    try {
      const t = (req.headers.authorization || '').replace('Bearer ', '');
      req.user = jwt.verify(t, SECRET);
    } catch (e) { return res.status(401).json({ error: 'Please login first' }); }
    if (role && req.user.role !== role) return res.status(403).json({ error: 'Not allowed for your role' });
    next();
  };
}

// ---------- Auth ----------
app.post('/api/register', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password || !['student', 'donor'].includes(role))
    return res.status(400).json({ error: 'All fields are required' });
  const db = read();
  if (db.users.find(u => u.email === email.toLowerCase()))
    return res.status(400).json({ error: 'Email already registered' });
  const user = { id: id(), name, email: email.toLowerCase(), role, hash: bcrypt.hashSync(password, 10) };
  db.users.push(user); write(db);
  res.json(session(user));
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = read().users.find(u => u.email === String(email).toLowerCase());
  if (!user || !bcrypt.compareSync(String(password), user.hash))
    return res.status(401).json({ error: 'Wrong email or password' });
  res.json(session(user));
});

function session(u) {
  const token = jwt.sign({ id: u.id, role: u.role, name: u.name }, SECRET, { expiresIn: '7d' });
  return { token, user: { id: u.id, name: u.name, role: u.role } };
}

// ---------- Books ----------
app.get('/api/books', (req, res) => {
  const q = String(req.query.q || '').toLowerCase();
  const db = read();
  const list = db.books
    .filter(b => !q || (b.title + ' ' + b.author).toLowerCase().includes(q))
    .map(b => ({ id: b.id, title: b.title, author: b.author, description: b.description,
                 donor: (db.users.find(u => u.id === b.donorId) || {}).name }));
  res.json(list.reverse());
});

app.post('/api/books', auth('donor'), (req, res) => {
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.message });
    const { title, author, description } = req.body;
    if (!title || !req.file) return res.status(400).json({ error: 'Title and book file are required' });
    const db = read();
    db.books.push({ id: id(), title, author: author || '', description: description || '',
                    file: req.file.filename, original: req.file.originalname, donorId: req.user.id });
    write(db);
    res.json({ ok: true });
  });
});

app.get('/api/my/books', auth('donor'), (req, res) => {
  res.json(read().books.filter(b => b.donorId === req.user.id)
    .map(b => ({ id: b.id, title: b.title, author: b.author })));
});

// ---------- Requests ----------
app.post('/api/requests', auth('student'), (req, res) => {
  const db = read();
  const book = db.books.find(b => b.id === req.body.bookId);
  if (!book) return res.status(404).json({ error: 'Book not found' });
  if (db.requests.find(r => r.bookId === book.id && r.studentId === req.user.id))
    return res.status(400).json({ error: 'You already requested this book' });
  db.requests.push({ id: id(), bookId: book.id, studentId: req.user.id, donorId: book.donorId,
                     status: 'pending', createdAt: new Date().toISOString() });
  write(db);
  res.json({ ok: true });
});

app.get('/api/requests/mine', auth('student'), (req, res) => {
  const db = read();
  res.json(db.requests.filter(r => r.studentId === req.user.id).map(r => ({
    id: r.id, status: r.status, createdAt: r.createdAt,
    title: (db.books.find(b => b.id === r.bookId) || {}).title
  })).reverse());
});

app.get('/api/requests/incoming', auth('donor'), (req, res) => {
  const db = read();
  res.json(db.requests.filter(r => r.donorId === req.user.id).map(r => ({
    id: r.id, status: r.status, createdAt: r.createdAt,
    title: (db.books.find(b => b.id === r.bookId) || {}).title,
    student: (db.users.find(u => u.id === r.studentId) || {}).name
  })).reverse());
});

function setStatus(status) {
  return (req, res) => {
    const db = read();
    const r = db.requests.find(x => x.id === req.params.id && x.donorId === req.user.id);
    if (!r) return res.status(404).json({ error: 'Request not found' });
    if (r.status !== 'pending') return res.status(400).json({ error: 'Already ' + r.status });
    r.status = status; r.completedAt = new Date().toISOString();
    write(db); res.json({ ok: true });
  };
}
app.post('/api/requests/:id/accept', auth('donor'), setStatus('completed'));
app.post('/api/requests/:id/reject', auth('donor'), setStatus('rejected'));

// Student downloads only after donor accepted
app.get('/api/requests/:id/download', auth('student'), (req, res) => {
  const db = read();
  const r = db.requests.find(x => x.id === req.params.id && x.studentId === req.user.id);
  if (!r || r.status !== 'completed') return res.status(403).json({ error: 'Not available yet' });
  const b = db.books.find(x => x.id === r.bookId);
  if (!b) return res.status(404).json({ error: 'Book missing' });
  res.download(path.join(UPLOADS, b.file), b.original);
});

app.listen(PORT, () => console.log('BookBridge running on port ' + PORT));
